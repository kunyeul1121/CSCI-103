#ifndef USER_H
#define USER_H

class User {
 public:

 private:

};


#endif
