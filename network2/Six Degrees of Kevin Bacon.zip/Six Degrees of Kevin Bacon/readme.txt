CSCI 103 Six Degrees of Kevin Bacon

Name: Stanley Kim

Email Address: stanlejk@usc.edu

NOTE: You can delete the questions, we only need your responses.

Please summarize the help you found useful for this assignment, which
may include office hours, discussion with peers, tutors, et cetera.
Saying "a CP on Tuesday" is ok if you don't remember their name.

:

================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

: 25+ hours

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

: My functions ran correctly, but when I ran the test with grade_input1,
I continuously got a bad_alloc error thrown. I didn't know how to resolve
this issue. I saw that it had to do with the "path.push_back()" I had in my 
line 213 of network.cpp, but I had no idea how to fix it. After asking friends 
and researching online, I still could not find an answer and it was just 
getting later and later past the deadline so I gave up and turned it in. :/ 


Do you have any other remarks?

: I thought the extra day due to bits being down did not count as a grace 
day; I had saved 2 grace days the entire semester which I thought would 
last me until tomorrow (Sunday) because it was a very tough PA. When I got 
off work at 10:30 PM Saturday and saw Piazza, which said the PA was due 
Saturday midnight, I panicked because I knew I was stuck on suggest_friends 
and scrambled to finish it. Although I unfortunately could not meet the 
deadline of Saturday midnight and the PA would not run with certain tests, I 
hope you can see the hard work I put into my program and can see that most of 
my functions are working.
