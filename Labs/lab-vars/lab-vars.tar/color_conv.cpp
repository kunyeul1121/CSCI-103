#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
   // Enter your code here
   
   
   
   
   return 0;
}
